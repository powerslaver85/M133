
SETUP:
ACHTUNG: Das Verzeichnis muss sich im ordner htdocs bzw. www (WAMP) befinden:
BSP: C:\XAMPP\htdocs\5H\m133projekt2\schenk\laravel\usw.

1. Die Datei SQL_SETUP.sql aus dem Ordner H5\m133projekt2\schenk\laravel\other\
   mittels Import in PHPmyAdmin importieren. (DB wird erstellt)

2. Die Website mit der Adresse localhost/H5/m133projekt2/schenk/laravel/public/ ansteuern
   (Um Probleme mit dem Routing zu vermeiden habe ich mich entschieden die Lange Adresse zu nehmen.)
